from accounts.models import User
from netsuite.models import NetSuiteConnection
from django.db import transaction


class NetSuiteConnectionRepository:
    """
    Persistence-only operations for NetSuiteConnection.

    Contains no OAuth/HTTP logic — token exchange happens in
    NetSuiteAuthClient (client.py), orchestration in
    NetSuiteConnectionService (services.py). This class only reads from
    and writes to the database.
    """

    def get_by_user(self, user: User) -> NetSuiteConnection | None:
        return NetSuiteConnection.objects.filter(user=user,is_active=True).first()

    def upsert(
        self,
        *,
        user: User,
        client_name:str,
        environment: str,
        client_id: str,
        client_secret: str,
        netsuite_account_id: str,
        access_token: str,
        refresh_token: str,
        access_token_expires_at,
        refresh_token_expires_at=None,
    ) -> NetSuiteConnection:
        """
        Create or replace the single connection row for this user. A user
        has at most one active NetSuite connection at a time
        (OneToOneField), so reconnecting overwrites the previous tokens
        rather than creating a duplicate row.
        """
        with transaction.atomic():
            NetSuiteConnection.objects.filter(
                user=user,
                is_active=True,
            ).update(is_active=False)
            connection = NetSuiteConnection.objects.filter(
                user=user,
                netsuite_account_id=netsuite_account_id,
            ).first()

            if connection:
                connection.client_name = client_name
                connection.environment = environment
                connection.client_id = client_id
                connection.client_secret = client_secret
                connection.access_token = access_token
                connection.refresh_token = refresh_token
                connection.access_token_expires_at = access_token_expires_at
                connection.refresh_token_expires_at = refresh_token_expires_at
                connection.status = "connected"
                connection.is_active = True
                connection.save()
            else:
                connection = NetSuiteConnection.objects.create(
                user=user,
                client_name = client_name,
                environment = environment,
                client_id=client_id,
                client_secret=client_secret,
                netsuite_account_id=netsuite_account_id,
                access_token=access_token,
                refresh_token=refresh_token,
                access_token_expires_at=access_token_expires_at,
                refresh_token_expires_at=refresh_token_expires_at,
                status="connected",
                is_active=True,
            )
        # connection, _ = NetSuiteConnection.objects.update_or_create(
        #     user=user,
        #     defaults={
        #         'netsuite_account_id': netsuite_account_id,
        #         'access_token': access_token,
        #         'refresh_token': refresh_token,
        #         'access_token_expires_at': access_token_expires_at,
        #         'refresh_token_expires_at': refresh_token_expires_at,
        #         'is_active': True,
        #     },
        # )
            return connection

    def update_tokens(
        self,
        connection: NetSuiteConnection,
        *,
        access_token: str,
        refresh_token: str,
        access_token_expires_at,
    ) -> NetSuiteConnection:
        """Persist a refreshed access/refresh token pair after a token-refresh call."""
        connection.access_token = access_token
        connection.refresh_token = refresh_token
        connection.access_token_expires_at = access_token_expires_at
        connection.status = "connected"
        connection.save(
            update_fields=[
                'access_token', 'refresh_token', 'access_token_expires_at','status', 'updated_at',
            ]
        )
        return connection

    def deactivate(self, connection: NetSuiteConnection) -> NetSuiteConnection:
        """Mark a connection inactive (e.g. on disconnect) without deleting history."""
        connection.is_active = False
        connection.save(update_fields=['is_active', 'updated_at'])
        return connection

    def list_by_user(self,user:User):
        return NetSuiteConnection.objects.filter(user=user).order_by("-is_active","-connected_at")
    
    def get_by_id(self,user:User,connection_id):
        return NetSuiteConnection.objects.filter(
            user=user,
            id=connection_id,
        ).first()
    
    def switch_active_connection(self, user: User, connection: NetSuiteConnection):
        with transaction.atomic():
            NetSuiteConnection.objects.filter(
                user=user,
                is_active=True,
            ).update(is_active=False)

            connection.is_active = True
            connection.save(update_fields=["is_active", "updated_at"])

            return connection
    
    def create(
    self,
    *,
    user,
    client_name,
    environment,
    client_id,
    client_secret,
    netsuite_account_id,
):
        return NetSuiteConnection.objects.create(
        user=user,
        client_name=client_name,
        environment=environment,
        client_id=client_id,
        client_secret=client_secret,
        netsuite_account_id=netsuite_account_id,
        status="pending",
        is_active=False,
    )

    def rename(
    self,
    connection: NetSuiteConnection,
    client_name: str,):
        connection.client_name = client_name
        connection.save(update_fields=["client_name", "updated_at"])
        return connection

    def delete(self, connection: NetSuiteConnection):
        with transaction.atomic():

            user = connection.user
            was_active = connection.is_active

            connection.delete()

            if was_active:
                next_connection = (
                    NetSuiteConnection.objects.filter(
                        user=user,
                        status="connected",
                    )
                    .order_by("connected_at")
                    .first()
                )

                if next_connection:
                    next_connection.is_active = True
                    next_connection.save(update_fields=["is_active", "updated_at"])